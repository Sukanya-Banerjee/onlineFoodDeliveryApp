package org.anudip.onlineFoodDeliveryApp.dao;

import java.util.List;

import org.anudip.onlineFoodDeliveryApp.bean.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
@Repository
public class OrderDaoImpl implements OrderDao {
	@Autowired
	private OrderRepository repository;
	
	@Override
	public void saveOrder(Order order) {
		repository.save(order);

	}

	@Override
	public List<Order> displayAllOrder() {
		return repository.findAll();
	}

	@Override
	public List<Order> findOrdersByCustomerUnpaid( Integer customerId,String payStatus){
		return repository.findOrdersByCustomerUnpaid(customerId, payStatus);
	}
	
	@Override
	public Long generateNewOrderId() {
	    Long newId = 1L;
	    int val = repository.getOrderCount();
	    if (val == 0)
	        newId = 1L;
	    else 
	    	newId = val+1L;
	    
	    return newId;
	}
}