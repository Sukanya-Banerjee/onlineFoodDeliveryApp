package org.anudip.onlineFoodDeliveryApp.dao;

import java.util.List;

import org.anudip.onlineFoodDeliveryApp.bean.Restaurant;

public interface RestaurantDao {

			public void saveRestaurant(Restaurant restaurant); 
			public List<Restaurant> displayAllRestaurant();

			public Restaurant findARestaurantById(String restaurantId);

			public String generateNewRestaurantId();
		}