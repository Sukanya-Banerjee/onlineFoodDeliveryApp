package org.anudip.onlineFoodDeliveryApp.dao;
import java.util.List;

import org.anudip.onlineFoodDeliveryApp.bean.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface OrderRepository extends JpaRepository<Order,Long> {
	@Query("select count(orderId) from Order")
	public int getOrderCount();
	@Query("SELECT o FROM Order o WHERE o.customerId = ?1 and o.payStatus = ?2")
	List<Order> findOrdersByCustomerUnpaid( Integer customerId,String payStatus);
}