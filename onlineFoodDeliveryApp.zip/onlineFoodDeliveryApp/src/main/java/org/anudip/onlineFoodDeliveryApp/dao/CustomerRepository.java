package org.anudip.onlineFoodDeliveryApp.dao;
import org.anudip.onlineFoodDeliveryApp.bean.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

public interface CustomerRepository extends JpaRepository<Customer,Integer> {
	
	@Query("select count(customerId) from Customer")
	public int getCustomerCount();
	
}
