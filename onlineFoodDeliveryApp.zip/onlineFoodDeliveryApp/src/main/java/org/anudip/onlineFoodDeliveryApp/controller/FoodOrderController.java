package org.anudip.onlineFoodDeliveryApp.controller;
//import java.util.ArrayList;
import java.util.List;

import org.anudip.onlineFoodDeliveryApp.bean.Bill;
import org.anudip.onlineFoodDeliveryApp.bean.Customer;
import org.anudip.onlineFoodDeliveryApp.bean.Order;
import org.anudip.onlineFoodDeliveryApp.bean.Restaurant;
import org.anudip.onlineFoodDeliveryApp.dao.BillDao;
import org.anudip.onlineFoodDeliveryApp.dao.CustomerDao;
import org.anudip.onlineFoodDeliveryApp.dao.OrderDao;
import org.anudip.onlineFoodDeliveryApp.dao.RestaurantDao;
import org.anudip.onlineFoodDeliveryApp.service.BillService;
//import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class FoodOrderController {

    @Autowired
    private CustomerDao customerDao;
    @Autowired
    private RestaurantDao restaurantDao;
    
    @Autowired
    private OrderDao orderDao;
    @Autowired
    private BillService service;
    
    @Autowired
    private BillDao billDao;
       
    

    @GetMapping("/index")
	public ModelAndView showIndexPage() {
		return new ModelAndView("index");
	}
    @GetMapping("/customerEntry")
	public ModelAndView showCustomerEntry() {
	ModelAndView mv = new ModelAndView("customerEntry");
	Integer newId = customerDao.generateNewCustomerId();
	Customer customer = new Customer(newId);
	mv.addObject("customerRecord", customer);
	return mv;
	}
	@PostMapping("/customerEntry")
	public ModelAndView saveUpdateCustomer(@ModelAttribute("customerRecord")Customer customer) {
	customerDao.saveCustomer(customer);
	return new ModelAndView("redirect:/index");
	}
	
	@GetMapping("/restaurantEntry")
	public ModelAndView showRestaurantEntry() {
	ModelAndView mv = new ModelAndView("restaurantEntry");
	String newId = restaurantDao.generateNewRestaurantId();
	Restaurant restaurant = new Restaurant(newId);
	mv.addObject("restaurantRecord", restaurant);
	return mv;
	}	
	@PostMapping("/restaurantEntry")
	public ModelAndView saveUpdateRestaurant(@ModelAttribute("restaurantRecord")Restaurant restaurant) {
	restaurantDao.saveRestaurant(restaurant);
	return new ModelAndView("redirect:/index");
	}
		
	 // Code for "Customer List" page
    @GetMapping("/customerList")
    public ModelAndView showCustomerList() {
        ModelAndView mv = new ModelAndView("customerList");
       
        List<Customer> customerList = customerDao.displayAllCustomer(); // Assuming you have a method like displayAllCustomer in your CustomerDao
            mv.addObject("customerList", customerList);
            return mv;
        }
           
     // Code for "Restaurant List" page
    @GetMapping("/restaurantList")
    public ModelAndView showrestaurantList() {
        ModelAndView mv = new ModelAndView("restaurantList");
        List<Restaurant> restaurantList = restaurantDao.displayAllRestaurant(); 
        mv.addObject("restaurantList", restaurantList);
            return mv;
        }

    @GetMapping("/orderBooking")
	public ModelAndView showOrderBooking() {
	ModelAndView mv = new ModelAndView("orderBooking");
	Long newId = orderDao.generateNewOrderId();
	Order order = new Order(newId);
	mv.addObject("orderRecord", order);
	return mv;
	}
    @PostMapping("/orderBooking")
	public ModelAndView saveUpdateOrder(@ModelAttribute("orderRecord")Order order) {
	orderDao.saveOrder(order);
	return new ModelAndView("redirect:/index");
	}
    @GetMapping("/billEntry")
	public ModelAndView showBillEntry() {
		return new ModelAndView("billEntry");
	}
    @PostMapping("/billEntry")
    
    public ModelAndView saveUpdateBillEntry(@RequestParam("customerId") int customerId) {
    	Customer customer=customerDao.findACustomerById(customerId);
    	double totalAmount= service.totalAmountCalculation(customer);
    	Bill bill= new Bill(customerId,totalAmount);
    	billDao.saveBill(bill);
    	return new ModelAndView("redirect:/index");
    	}
    	
    @GetMapping("/billPaid")
	public ModelAndView showBillPaid() {
		return new ModelAndView("billPaid");
	}
    @PostMapping("/billPaid")
    public ModelAndView saveUpdateBillPaid(@RequestParam("customerId") int customerId) {
    	Customer customer=customerDao.findACustomerById(customerId);
    	double totalAmount= service.totalAmountCalculation(customer);
    	Bill bill= new Bill(customerId,totalAmount);
    	billDao.saveBill(bill);
    	return new ModelAndView("redirect:/index");
    	}
           

  /* // Code for "Bill Paid" page
    @GetMapping("/billPaid")
    public ModelAndView showBillPaid() {
        ModelAndView mv = new ModelAndView("billPaid");
        Integer newId = billDao.generateNewBillId();
    	Bill bill = new Bill(newId);
    	mv.addObject("billRecord", bill);
        return mv;
    }*/
    
  /*  @GetMapping("/orderDetails/{orderId}") // Example GetMapping for fetching order details by ID
    public ModelAndView getOrderDetails(@PathVariable Long orderId) {
        ModelAndView mv = new ModelAndView("OrderCount");
        Order order = OrderBooking.get(orderId); // Assuming you have a method to fetch order details
        if (order != null) {
            mv.addObject("order", order);
        } else {
            mv.addObject("errorMessage", "Order not found");
        }
        return mv;
    }*/
    
}